import { useEffect, useState } from "react";
import "./App.css";

function App() {
  // Holds the text we show for backend status ("checking...", "ok", or "unavailable")
  const [backendStatus, setBackendStatus] = useState("checking...");

  useEffect(() => {
    // Call the FastAPI backend's /health route to confirm it's running
    fetch("http://127.0.0.1:8000/health")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Backend responded with an error");
        }
        return response.json();
      })
      .then((data) => {
        setBackendStatus(data.status); // expected: "ok"
      })
      .catch(() => {
        setBackendStatus("unavailable");
      });
  }, []);

  return (
    <div className="app-container">
      <h1>AI Pull Request Assistant</h1>
      <p>Analyze GitHub Pull Requests using Artificial Intelligence.</p>

      <div className="status-box">
        {backendStatus === "unavailable" ? (
          <p>Backend unavailable</p>
        ) : (
          <p>Backend Status: {backendStatus}</p>
        )}
      </div>
    </div>
  );
}

export default App;
