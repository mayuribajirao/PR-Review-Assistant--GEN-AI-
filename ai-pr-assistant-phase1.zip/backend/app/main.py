from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Create the FastAPI application instance
app = FastAPI(title="AI Pull Request Assistant API")

# Allow the React development server (Vite) to call this API.
# Without this, the browser blocks requests due to CORS policy.
origins = [
    "http://localhost:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def read_root():
    """Basic route to confirm the API is running."""
    return {"message": "AI Pull Request Assistant API is running"}


@app.get("/health")
def health_check():
    """Health check route used by the frontend to verify backend connectivity."""
    return {"status": "ok"}
